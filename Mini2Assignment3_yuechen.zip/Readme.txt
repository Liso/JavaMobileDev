Author: Yue Chen


Please find ArtistMartket.apk in the tarball, and install it in android device to run the application.

Please find the source code in the ArtistMarket folder.

Given the limited space, if you want to play the videos, please push the poker_face_v.mp4 and applause.mp4, which are enclosed in the tarball into the root path of the sd card.

In the main activity, there are four buttons, one in the right top corner and the other three on the bottom.

Clicking on the set wallpaper button will change the wallpaper of your device to the picture you are browsing.