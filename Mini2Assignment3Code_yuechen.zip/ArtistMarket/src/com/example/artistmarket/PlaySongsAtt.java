package com.example.artistmarket;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioGroup;

public class PlaySongsAtt extends Activity implements OnClickListener {

	static final String AUDIO_PATH =
			"http://URL to .mp3 file";
	private Button btnplay;
	private Button btnpause;
	private Button btnstop;
	private RadioGroup radioTracks;
	private MediaPlayer mediaPlayer;
	private int trackId = 0;
	private int playbackPosition = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_play_songs_att);

		btnplay = (Button)findViewById(R.id.play);
		btnplay.setOnClickListener(this);
		btnpause = (Button)findViewById(R.id.pause);
		btnpause.setOnClickListener(this);
		btnstop = (Button)findViewById(R.id.stop);
		btnstop.setOnClickListener(this);
		radioTracks = (RadioGroup)findViewById(R.id.radioTracks);
	}
	/*
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.play_songs_att, menu);
		return true;
	}
	 */
	@Override
	public void onClick(View v)
	{
		if (v.equals(btnpause)) {
			if(mediaPlayer!=null)
			{
				playbackPosition = mediaPlayer.getCurrentPosition();
				mediaPlayer.pause();
			}
		}

		if (v.equals(btnplay)) {
			try 
			{
				//playAudio(AUDIO_PATH);
				//playLocalAudio();

				int selectedId = radioTracks.getCheckedRadioButtonId();
				if (selectedId != trackId) {
					playbackPosition = 0;
					switch (selectedId) {
					case R.id.track1:
						playLocalAudio_UsingDescriptor(R.raw.bad_romance);
						break;
					case R.id.track2:
						playLocalAudio_UsingDescriptor(R.raw.do_what_u_want);
						break;
					case R.id.track3:
						playLocalAudio_UsingDescriptor(R.raw.poker_face);
						break;
					}
					trackId = selectedId;
				}
				else {
					if(mediaPlayer!=null && !mediaPlayer.isPlaying())
					{
						mediaPlayer.seekTo(playbackPosition);
						mediaPlayer.start();
					}

				}

			} catch (Exception e) 
			{
				e.printStackTrace();
			}
		}


		if (v.equals(btnstop)) {
			killMediaPlayer();
		}

	}

	private void playAudio(String url)throws Exception
	{
		killMediaPlayer();
		mediaPlayer = new MediaPlayer();
		mediaPlayer.setDataSource(url);
		mediaPlayer.prepare();
		mediaPlayer.start();
	}
	
	@Override
	protected void onResume() {
	    super.onResume();
	};
	
	@Override
	protected void onStop() {
		super.onStop();
	};
	
	@Override
	protected void onDestroy()
	{
		super.onDestroy();
		killMediaPlayer();
	}

	private void killMediaPlayer()
	{
		if(mediaPlayer!=null)
		{
			try
			{
				mediaPlayer.release();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	} 	

	private void playLocalAudio()throws Exception
	{
		mediaPlayer = MediaPlayer.create(this, R.raw.poker_face);
		mediaPlayer.start();
	}

	private void playLocalAudio_UsingDescriptor(int id) throws Exception 
	{
		killMediaPlayer();
		AssetFileDescriptor fileDesc = getResources().openRawResourceFd(id);
		if (fileDesc != null) 
		{
			mediaPlayer = new MediaPlayer();
			mediaPlayer.setDataSource(fileDesc.getFileDescriptor(), fileDesc.getStartOffset(), fileDesc.getLength());
			fileDesc.close();
			mediaPlayer.prepare();
			mediaPlayer.start();
		}
	}


}
