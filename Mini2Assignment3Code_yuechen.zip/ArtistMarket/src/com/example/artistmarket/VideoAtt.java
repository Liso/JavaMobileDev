package com.example.artistmarket;


import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.VideoView;

public class VideoAtt extends Activity implements OnClickListener, OnCheckedChangeListener{

	private VideoView videoView;
	private Button btnhome;
	private RadioGroup videoTracks;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_video_att);
    
		btnhome = (Button) findViewById(R.id.home);
		btnhome.setOnClickListener(this);
		videoTracks = (RadioGroup)findViewById(R.id.videotracks);
		videoTracks.setOnCheckedChangeListener(this);
        videoView = (VideoView)this.findViewById(R.id.videoView1);
        MediaController mc = new MediaController(this);
        mc.setAnchorView(videoView);
        videoView.setMediaController(mc);
        videoView.requestFocus();
        /*
        //videoView.setVideoURI(Uri.parse("http://URL to mp4 file"));
        videoView.setVideoPath("/sdcard/poker_face_v.mp4");
        videoView.start();
        */
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.video_att, menu);
		return true;
	}
	
	@Override
	protected void onDestroy()
	{
		super.onDestroy();
	}
	

	@Override
	public void onClick(View v)
	{
		if (v.equals(btnhome)) {
			Intent intent = new Intent(VideoAtt.this, MainActivity.class);
			startActivity(intent);
			android.os.Process.killProcess(android.os.Process.myPid());
		}
	}
	

	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {
		
		if (checkedId == R.id.pokerfacev) {
	        videoView.setVideoPath("/sdcard/poker_face_v.mp4");
	        videoView.start();
		}
		else if (checkedId == R.id.applause) {
	        videoView.setVideoPath("/sdcard`/applause.mp4");
	        videoView.start();
		}
		
	}

}
