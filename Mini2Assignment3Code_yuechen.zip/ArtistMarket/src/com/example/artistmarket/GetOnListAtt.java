package com.example.artistmarket;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

public class GetOnListAtt extends Activity implements OnClickListener{

	private Button btnhome;
	private Button btnsubmit;
	private EditText personName;
	private EditText personEmail;
	private EditText message;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_get_on_list_att);
		
		btnhome = (Button) findViewById(R.id.home);
		btnhome.setOnClickListener(this);
		btnsubmit = (Button) findViewById(R.id.submit);
		btnsubmit.setOnClickListener(this);
		personName = (EditText) findViewById(R.id.personName);
		personEmail = (EditText) findViewById(R.id.personEmail);
		message = (EditText) findViewById(R.id.message);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.get_on_list_att, menu);
		return true;
	}
	

	@Override
	public void onClick(View v) {
		if (v.equals(btnhome)) {
			Intent intent = new Intent(GetOnListAtt.this, MainActivity.class);
			startActivity(intent);
			android.os.Process.killProcess(android.os.Process.myPid());
		}
		
		if (v.equals(btnsubmit)) {
			  String to = "yuechen1989@gmail.com";
			  String subject = "Get on email list";
			  String body = "PersonName: " + personName.getText().toString() + "\n";
			  body = body + "Email: " + personEmail.getText().toString() + "\n";
			  body = body + "Message" + message.getText().toString() + "\n";

			  Intent email = new Intent(Intent.ACTION_SEND);
			  email.putExtra(Intent.EXTRA_EMAIL, new String[]{ to});
			  //email.putExtra(Intent.EXTRA_CC, new String[]{ to});
			  //email.putExtra(Intent.EXTRA_BCC, new String[]{to});
			  email.putExtra(Intent.EXTRA_SUBJECT, subject);
			  email.putExtra(Intent.EXTRA_TEXT, body);

			  //need this to prompts email client only
			  email.setType("message/rfc822");

			  startActivity(Intent.createChooser(email, "Choose an Email client :"));

		}
	}

}
