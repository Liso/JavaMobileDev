package com.example.artistmarket;

import java.io.IOException;

import android.os.Bundle;
import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Context;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ViewSwitcher.ViewFactory;

public class WallpaperAtt extends Activity implements OnClickListener {

	private static final int[] IMAGES = { R.drawable.profile, R.drawable.ladygaga1, R.drawable.ladygaga2,
		R.drawable.ladygaga3 };
	private int mPosition = 0;
	private Button btnset;
	private Button btnnext;
	private ImageSwitcher mImageSwitcher;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_wallpaper_att);

		btnset = (Button) findViewById(R.id.set);
		btnset.setOnClickListener(this);
		btnnext = (Button) findViewById(R.id.next);
		btnnext.setOnClickListener(this);

		mImageSwitcher = (ImageSwitcher) findViewById(R.id.imageSwitcher1);
		mImageSwitcher.setFactory(new ViewFactory() {
			@Override
			public View makeView() {
				ImageView imageView = new ImageView(WallpaperAtt.this);
				return imageView;
			}
		});
		mImageSwitcher.setInAnimation(this, android.R.anim.slide_in_left);
		mImageSwitcher.setOutAnimation(this, android.R.anim.slide_out_right);

		onSwitch(null);
	}

	public void onSwitch(View view) {
		mPosition = (mPosition + 1) % IMAGES.length;
		mImageSwitcher.setBackgroundResource(IMAGES[mPosition]);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.wallpaper_att, menu);
		return true;
	}

	@Override
	public void onClick(View v)
	{
		if (v.equals(btnset)) {        
			WallpaperManager myWallpaperManager 
            = WallpaperManager.getInstance(getApplicationContext());
            try {
                myWallpaperManager.setResource(IMAGES[mPosition]);
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

		}


		if (v.equals(btnnext)) {
			onSwitch(null);
		}
	}

}
