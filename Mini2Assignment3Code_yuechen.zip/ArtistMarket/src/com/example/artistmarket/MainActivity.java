package com.example.artistmarket;


import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.RatingBar;
import android.widget.Toast;
import android.widget.RatingBar.OnRatingBarChangeListener;
import android.widget.TextView;

public class MainActivity extends Activity implements OnClickListener {
	private Button btnsongs;
	private Button btnvideos;
	private Button btnwallpaper;
	private Button btnjoin;
	private TextView txtL;
	private TextView txtName;
	private RatingBar ratingBar;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.activity_main);



		
		txtL = (TextView) findViewById(R.id.l);
		Typeface font = Typeface.createFromAsset(getAssets(), "impact.ttf");
		txtL.setTypeface(font);
		txtName = (TextView) findViewById(R.id.artistname);
		txtName.setTypeface(font);
		ratingBar = (RatingBar) findViewById(R.id.ratingBar1);


		btnjoin = (Button) findViewById(R.id.join);
		btnjoin.setOnClickListener(this);
		btnsongs = (Button) findViewById(R.id.songs);
		btnsongs.setOnClickListener(this);
		btnvideos = (Button) findViewById(R.id.videos);
		btnvideos.setOnClickListener(this);
		btnwallpaper = (Button) findViewById(R.id.btnwallpaper);
		btnwallpaper.setOnClickListener(this);

	}

	public void addListenerOnRatingBar() {


		//if rating value is changed,
		//display the current rating value in the result (textview) automatically
		ratingBar.setOnRatingBarChangeListener(new OnRatingBarChangeListener() {
			public void onRatingChanged(RatingBar ratingBar, float rating,
					boolean fromUser) {

				//					txtRatingValue.setText(String.valueOf(rating));

			}
		});
	}

	@Override
	public void onClick(View v)
	{
		if (v.equals(btnsongs)) {
			Intent intent = new Intent(MainActivity.this, PlaySongsAtt.class);
			startActivity(intent);
		}

		if (v.equals(btnvideos)) {
			Intent intent = new Intent(MainActivity.this, VideoAtt.class);
			startActivity(intent);
		}

		if (v.equals(btnwallpaper)) {
			Intent intent = new Intent(MainActivity.this, WallpaperAtt.class);
			startActivity(intent);
		}

		if (v.equals(btnjoin)) {
			Intent intent = new Intent(MainActivity.this, GetOnListAtt.class);
			startActivity(intent);
		}
	}


}
